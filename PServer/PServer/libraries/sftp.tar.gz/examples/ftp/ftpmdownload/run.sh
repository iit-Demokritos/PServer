#!/bin/sh
javac -classpath .:../../../lib/sftp.jar -d . FtpMdownloadExample.java
java -cp .:../../../lib/sftp.jar FtpMdownloadExample
